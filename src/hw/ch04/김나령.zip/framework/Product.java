package hw.ch04.framework;

public abstract class Product {
    public abstract void use();
    public abstract String getModelName();

}
