package hw.ch10;

public interface Comparable<Student> {
    public abstract int compareTo(Student s);
    public abstract String toString();
}
