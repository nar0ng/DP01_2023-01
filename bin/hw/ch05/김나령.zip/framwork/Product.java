package hw.ch05.framwork;

public abstract class Product {
    public abstract void use();
}
